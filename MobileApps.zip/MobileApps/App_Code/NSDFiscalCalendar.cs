﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Nucor;

/// <summary>
/// Summary description for NSDFiscalCalendar
/// </summary>
public class NSDFiscalCalendar
{
    public enum Month
    {
        Jan = 1,
        Feb,
        Mar,
        Apr,
        May,
        Jun,
        Jul,
        Aug,
        Sep,
        Oct,
        Nov,
        Dec
    }

    public static DateTime GetWeekStart(DateTime start)
    {
        double offset = 0;
        switch (start.DayOfWeek)
        {
            case DayOfWeek.Monday:
                offset = -1;
                break;
            case DayOfWeek.Tuesday:
                offset = -2;
                break;
            case DayOfWeek.Wednesday:
                offset = -3;
                break;
            case DayOfWeek.Thursday:
                offset = -4;
                break;
            case DayOfWeek.Friday:
                offset = -5;
                break;
            case DayOfWeek.Saturday:
                offset = -6;
                break;
            case DayOfWeek.Sunday:
                offset = 0;
                break;
        }
        return start.AddDays(offset);
    }

    public static DateTime AdjustDateIfShiftSpansMidnight(DateTime date)
    {
        //Roll the date back if we're still on Night Shift
        if (DateTime.Now >= Convert.ToDateTime(date.ToShortDateString() + " 12:00:00 AM")
            && DateTime.Now < Convert.ToDateTime(date.ToShortDateString() + " 7:00:00 AM"))
        {
            return date.AddDays(-1);
        }

        return date;
    }


    //public static DateTime GetMonthStart(Month month, String year)
    //{
    //    return GetMonthStart((int)month, year);
    //}


    //public static DateTime GetMonthStart(int month, String year)
    //{
    //    HMProdDataContext db = new HMProdDataContext();
    //    var query = (from p in db.fiscal_calendars
    //                 where p.fiscal_month_number == month
    //                 where p.fiscal_year == year
    //                 select p.fiscal_start_date).SingleOrDefault();
    //    return query.Value;
    //}

    public static DateTime GetMonthStart(DateTime date)
    {
        try
        {
            HMProdDataContext DM = new HMProdDataContext();
            var query = from i in DM.fiscal_calendars
                        where date >= i.fiscal_start_date
                        && date <= i.fiscal_end_date
                        select i.fiscal_start_date;

            if (query.Count() > 0)
            {
                date = Convert.ToDateTime(query.First());
            }
        }
        catch (Exception ex)
        {
            Emailer.LogException(ex);
        }

        return date;
    }

    public static DateTime GetMonthStart()
    {
        return GetMonthStart(DateTime.Now);
    }

    //public static DateTime GetMonthEnd(Month month, String year)
    //{
    //    return GetMonthEnd((int)month, year);
    //}

    //public static DateTime GetMonthEnd(int month, String year)
    //{
    //    HMProdDataContext db = new HMProdDataContext();
    //    var query = (from p in db.fiscal_calendars
    //                 where p.fiscal_month_number == month
    //                 where p.fiscal_year == year
    //                 select p.fiscal_end_date).SingleOrDefault();
    //    return query.Value;
    //}

    public static DateTime GetMonthEnd(DateTime date)
    {
        try
        {
            HMProdDataContext DM = new HMProdDataContext();
            var query = from i in DM.fiscal_calendars
                        where date >= i.fiscal_start_date
                        && date <= i.fiscal_end_date
                        select i.fiscal_end_date;

            if (query.Count() > 0)
            {
                date = Convert.ToDateTime(query.First());
            }
        }
        catch (Exception ex)
        {
            Emailer.LogException(ex);
        }

        return date;
    }

    public static DateTime GetMonthEnd()
    {
        return GetMonthEnd(DateTime.Now);
    }

}
