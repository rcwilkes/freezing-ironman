﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ShiftLogs_HMTunnelFurnaceLog : System.Web.UI.Page
{
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        TF_Log log = new TF_Log();
        ShiftLogDCDataContext DM = new ShiftLogDCDataContext();

        var iQList = from i in DM.TF_Logs
                     where i.date == LogMenu.Date.Value
                     && i.shift == LogMenu.Shift.Value
                     select i;
        if (iQList.Count() > 0)
        {
            log = iQList.FirstOrDefault();
        }

        if (!Page.IsPostBack)
        {
            SafetyIssues.Text = log.safety_comments == String.Empty ? "{Empty}" : log.safety_comments;
            GenComments.Text = log.general_comments == String.Empty ? "{Empty}" : log.general_comments;
            PMCompleted.Text = log.pm_comments == String.Empty ? "{Empty}" : log.pm_comments;
            RollsChanged.Text = log.rc_comments == String.Empty ? "{Empty}" : log.rc_comments;
            ScaleDumped.Text = log.scale_comments == String.Empty ? "{Empty}" : log.scale_comments;
            SoftwareComments.Text = log.soft_comments == String.Empty ? "{Empty}" : log.soft_comments;
            NeedsAttention.Text = log.na_comments == String.Empty ? "{Empty}" : log.na_comments;
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        LogMenu.PageTitle = "Tunnel Furn";
    }
}
