﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using Nucor;
using CML2.ShiftLogs;
using CML2.Common;

public partial class ShiftLogs_CMLog : System.Web.UI.Page
{
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        Shifts._Shifts shift;
        if (LogMenu.Shift.Value == "Day")
            shift = Shifts._Shifts.Days;
        else
            shift = Shifts._Shifts.Nights;

        Shifts shifts = Shifts.GetShiftDates(shift, LogMenu.Date.Value);
        ShiftLog log = ShiftLog_DAL.Get((int)LogMenu.ShiftLogType.Value, shifts.StartDate, shifts.EndDate);
        
        ReporterLabel.Text = log.Reporter == String.Empty ? "<span style='color: red;'>{Empty}</span>" : log.Reporter;
        CrewLabel.Text = NSD.Crew_DAL.GetByID(log.CrewID).Description;

        if (log.Comments.Count > 0)
        {
            foreach (ShiftLogComment comment in log.Comments)
            {
                ContentPlaceHolder.Controls.Add(new LiteralControl("<div style='color: #116611; font-weight: bold;'>" + comment.CommentTypeDescription + "</div>"));
                ContentPlaceHolder.Controls.Add(new LiteralControl("<span style='color:#333333'>" + comment.CommentText + "</span>"));
                ContentPlaceHolder.Controls.Add(new LiteralControl("<br><br>"));
            }
        }
        else
        {
            ContentPlaceHolder.Controls.Add(new LiteralControl("<span style='color: red;'>This log is empty.</span>"));
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        LogMenu.PageTitle = Page.Request.QueryString["type"];
        Page.Title = Page.Request.QueryString["type"] + " Log";
    }
}
