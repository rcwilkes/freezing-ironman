﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using CML2.ShiftLogs;
using System.Collections.Generic;

public partial class CMLogMenu : System.Web.UI.Page
{
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        PlaceHolder holder = (PlaceHolder)Page.Master.FindControl("MainPlaceHolder");
        holder.Controls.Add(new LiteralControl("> <span style='font-weight: bold;'>CM Logs</span>"));

        Table t = new Table();
        t.CellPadding = 1;
        t.CellSpacing = 2;

        ShiftLog_DMDataContext DM = new ShiftLog_DMDataContext(CML2Config.ConnectionStrings.NSDConnString);

        List<CML2_ShiftLogType> types = new List<CML2_ShiftLogType>();
        var iQList = from i in DM.CML2_ShiftLogTypes
                     orderby i.ShiftLogTypeDescription
                     select i;

        foreach (CML2_ShiftLogType type in iQList)
        {
            TableRow r = new TableRow();
            TableCell c1 = new TableCell();

            HyperLink link = new HyperLink();
            link.Font.Size = FontUnit.Point(8);
            link.Text = type.ShiftLogTypeDescription;// logType.ToString();
            link.NavigateUrl = "~/ShiftLogs/CMLog.aspx?mill=CM&type=" + (ShiftLogTypes._ShiftLogTypes)type.ShiftLogTypeID;

            c1.Controls.Add(new LiteralControl("&nbsp;&nbsp;<img src='../images/blue_square.png' />&nbsp;"));
            c1.Controls.Add(link);

            r.Cells.Add(c1);
            t.Rows.Add(r);

            ContentPlaceHolder.Controls.Add(t);
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
