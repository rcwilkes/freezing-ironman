﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ShiftLogs_HMShippingLog : System.Web.UI.Page
{
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        Shipping_Log log = new Shipping_Log();
        ShiftLogDCDataContext DM = new ShiftLogDCDataContext();

        var iQList = from i in DM.Shipping_Logs
                     where i.date == LogMenu.Date.Value
                     && i.shift == LogMenu.Shift.Value
                     select i;
        if (iQList.Count() > 0)
        {
            log = iQList.FirstOrDefault();
        }

        if (!Page.IsPostBack)
        {
            SafetyIssues.Text = log.safety_comments;
            BargeCommentsLabel.Text = log.barge_comments;
            OtherCommentsLabel.Text = log.other_comments;

            HMRailcarsLoadedLabel.Text = log.railcars_loaded_hm.ToString();
            CMRailcarsLoadedLabel.Text = log.railcars_loaded_cm.ToString();
            HMRailcarsProgLabel.Text = log.railcars_in_prog_hm.ToString();
            CMRailcarsProgLabel.Text = log.railcars_in_prog_cm.ToString();

            NSCoveredHMCarsLabel.Text = log.ns_covered_hm.ToString();
            NSCoveredHMLoadsLabel.Text = log.ns_covered_hm_loads.ToString();
            NSCoveredCMCarsLabel.Text = log.ns_covered_cm.ToString();
            NSCoveredCMLoadsLabel.Text = log.ns_covered_cm_loads.ToString();

            NSOpenHMCarsLabel.Text = log.ns_open_hm.ToString();
            NSOpenHMLoadsLabel.Text = log.ns_open_hm_loads.ToString();
            NSOpenCMCarsLabel.Text = log.ns_open_cm.ToString();
            NSOpenCMLoadsLabel.Text = log.ns_open_cm_loads.ToString();

            CSXTCoveredHMCarsLabel.Text = log.csxt_covered_hm.ToString();
            CSXTCoveredHMLoadsLabel.Text = log.csxt_covered_hm_loads.ToString();
            CSXTCoveredCMCarsLabel.Text = "NA";
            CSXTCoveredCMLoadsLabel.Text = "NA";

            CSXTOpenHMCarsLabel.Text = log.csxt_open_hm.ToString();
            CSXTOpenHMLoadsLabel.Text = log.csxt_open_hm_loads.ToString();
            CSXTOpenCMCarsLabel.Text = "NA";
            CSXTOpenCMLoadsLabel.Text = "NA";

            SwitchHMCarsLabel.Text = log.switch_hm;
            SwitchCMCarsLabel.Text = log.switch_cm;
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        LogMenu.PageTitle = "Shipping";
    }
}
