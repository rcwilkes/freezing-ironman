﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ShiftLogs_HMLog : System.Web.UI.Page
{
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        HM_Log log = new HM_Log();
        ShiftLogDCDataContext DM = new ShiftLogDCDataContext();

        var iQList = from i in DM.HM_Logs
                     where i.date == LogMenu.Date.Value
                     && i.shift == LogMenu.Shift.Value
                     select i;
        if (iQList.Count() > 0)
        {
            log = iQList.FirstOrDefault();
        }

        if (!Page.IsPostBack)
        {
            SafetyIssues.Text = log.safety_comments == String.Empty ? "{Empty}" : log.safety_comments;
            ProdComments.Text = log.prod_comments == String.Empty ? "{Empty}" : log.prod_comments;
            QualityComments.Text = log.qual_comments == String.Empty ? "{Empty}" : log.qual_comments;
            MechComments.Text = log.mech_comments == String.Empty ? "{Empty}" : log.mech_comments;
            ElectricalComments.Text = log.elec_comments == String.Empty ? "{Empty}" : log.elec_comments;
            SoftwareComments.Text = log.soft_comments == String.Empty ? "{Empty}" : log.soft_comments;
            DelayComments.Text = log.delay_comments == String.Empty ? "{Empty}" : log.delay_comments;
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        LogMenu.PageTitle = "Hot Mill";
    }
}
