﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Nucor;

using CML2.ShiftLogs;

public partial class UserControls_ShiftLogMenu : System.Web.UI.UserControl
{
    public enum ShiftChange
    {
        Next,
        Previous
    }

    public string PageTitle = String.Empty;
    public NuState<string> Shift = new NuState<string>("shift", "Day");
    public NuState<DateTime> Date = new NuState<DateTime>("date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
    public NuState<ShiftLogTypes._ShiftLogTypes> ShiftLogType = new NuState<ShiftLogTypes._ShiftLogTypes>("type", ShiftLogTypes._ShiftLogTypes.Supervisor);
    public NuState<string> Mill = new NuState<string>("mill", "HM");

    string GetShiftChangeUrl(ShiftChange shiftChange)
    {
        string url = String.Empty;
        
        if (Shift.Value == "Day" && shiftChange == ShiftChange.Next)
            url = Page.Request.Path + "?"
            + Date.ToQueryString() + "&"
            + Shift.ToQueryString("Night") + "&"
            + Mill.ToQueryString();
        else if (Shift.Value == "Day" && shiftChange == ShiftChange.Previous)
            url = Page.Request.Path + "?"
            + Date.ToQueryString(Date.Value.AddDays(-1)) + "&"
            + Shift.ToQueryString("Night") + "&"
            + Mill.ToQueryString();
        else if (Shift.Value == "Night" && shiftChange == ShiftChange.Next)
            url = Page.Request.Path + "?"
            + Date.ToQueryString(Date.Value.AddDays(1)) + "&"
            + Shift.ToQueryString("Day") + "&"
            + Mill.ToQueryString();
        else if (Shift.Value == "Night" && shiftChange == ShiftChange.Previous)
            url = Page.Request.Path + "?"
            + Date.ToQueryString() + "&"
            + Shift.ToQueryString("Day") + "&"
            + Mill.ToQueryString();
        else
            url = Page.Request.Path;

        if (Mill.Value == "CM")
            url += "&" + ShiftLogType.ToQueryString();

        return url;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Roll the date back if we're still on Night Shift
        if (DateTime.Now >= Convert.ToDateTime(Date.Value.ToShortDateString() + " 12:00:00 AM")
            && DateTime.Now < Convert.ToDateTime(Date.Value.ToShortDateString() + " 7:00:00 AM"))
        {
            Date.Value = Date.Value.AddDays(-1);
            Shift.Value = "Night";
        }//Change the shift to Night if it's after 7PM
        else if (DateTime.Now >= Convert.ToDateTime(Date.Value.ToShortDateString() + " 7:00:00 PM"))
        {
            Shift.Value = "Night";
        }


        if (Page.Request.QueryString[Shift.Key] != null)
            Shift.Value = Page.Request.QueryString[Shift.Key];
        if (Page.Request.QueryString[Date.Key] != null)
            Date.Value = Convert.ToDateTime(Page.Request.QueryString[Date.Key]);
        if (Page.Request.QueryString[Mill.Key] != null)
            Mill.Value = Page.Request.QueryString[Mill.Key];
        if (Page.Request.QueryString[ShiftLogType.Key] != null)
            ShiftLogType.Value = Page.Request.QueryString[ShiftLogType.Key].Cast<ShiftLogTypes._ShiftLogTypes>();


        HyperLink link = new HyperLink();
        link.Text = "Logs";
        link.NavigateUrl = Mill.Value == "HM" ? "~/ShiftLogs/HMLogMenu.aspx" : "~/ShiftLogs/CMLogMenu.aspx";
        link.Font.Bold = true;
        PlaceHolder holder = (PlaceHolder)Page.Master.FindControl("MainPlaceHolder");
        holder.Controls.Add(new LiteralControl(" > "));
        holder.Controls.Add(link);
        holder.Controls.Add(new LiteralControl(" > "));
        holder.Controls.Add(new LiteralControl("<span style='font-weight: bold;'>" + PageTitle + "</span>"));

        GoButton.Command += new CommandEventHandler(GoButton_Command);
        PrevButton.NavigateUrl = GetShiftChangeUrl(ShiftChange.Previous);
        NextButton.NavigateUrl = GetShiftChangeUrl(ShiftChange.Next);

        if (!Page.IsPostBack)
        {
            DateTextBox.Text = Date.Value.ToShortDateString() + " " + Shift.Value;
        }
    }

    void GoButton_Command(object sender, CommandEventArgs e)
    {
        try
        {
            string url = Page.Request.Path + "?"
                + Date.ToQueryString(Convert.ToDateTime(DateTextBox.Text.Substring(0, DateTextBox.Text.IndexOf(' ')))) + "&"
                + Shift.ToQueryString() + "&"
                + "&" + Mill.ToQueryString();

            if (Mill.Value != String.Empty)
                url += "&" + ShiftLogType.ToQueryString();
             
            Page.Response.Redirect(url);
        }
        catch (Exception ex)
        {
            Emailer.LogException(ex);
            PageLabel.Text = ex.Message;
            PageLabel.ForeColor = System.Drawing.Color.Red;
        }
    }
}
