﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class HMStationStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PlaceHolder holder = (PlaceHolder)Page.Master.FindControl("MainPlaceHolder");
        holder.Controls.Add(new LiteralControl(" > "));
        holder.Controls.Add(new LiteralControl("<span style='font-weight: bold;'>HM Plant Status</span>"));

        char s1 = Convert.ToChar("S");
        char s2 = Convert.ToChar("N");
        char t1 = Convert.ToChar("E");
        char t2 = Convert.ToChar("L");

        this.LBLSEAFStatus.Text = "<font color='" + getColor(getMeltShopStatus(s1, t1)) + "'>" + getMeltShopStatus(s1, t1) + "</font>";
        this.LBLSEAFGrade.Text = "<font color='" + getColor(getMeltShopStatus(s1, t1)) + "'>" + getGrade(s1, t1) + "</font>";
        this.LBLSEAFHeat.Text = "<font color='" + getColor(getMeltShopStatus(s1, t1)) + "'>" + getHeat(s1, t1) + "</font>";
        if (getMeltShopStatus(s1, t1) == "ON")
        {
            this.LBLSEAFImg.Text = "<img alt='' src='../Images/MFurnaceOnOff3.gif'/>";
        }
        else
        {
            this.LBLSEAFImg.Text = "<img alt='' src='../Images/MFurnaceOff.gif'/>";
        }

        this.LBLNEAFStatus.Text = "<font color='" + getColor(getMeltShopStatus(s2, t1)) + "'>" + getMeltShopStatus(s2, t1) + "</font>";
        this.LBLNEAFGrade.Text = "<font color='" + getColor(getMeltShopStatus(s2, t1)) + "'>" + getGrade(s2, t1) + "</font>";
        this.LBLNEAFHeat.Text = "<font color='" + getColor(getMeltShopStatus(s2, t1)) + "'>" + getHeat(s2, t1) + "</font>";
        if (getMeltShopStatus(s2, t1) == "ON")
        {
            this.LBLNEAFImg.Text = "<img alt='' src='../Images/MFurnaceOnOff3.gif'/>";
        }
        else
        {
            this.LBLNEAFImg.Text = "<img alt='' src='../Images/MFurnaceOff.gif'/>";
        }

        this.LBLSLMFStatus.Text = "<font color='" + getColor(getMeltShopStatus(s1, t2)) + "'>" + getMeltShopStatus(s1, t2) + "</font>";
        this.LBLSLMFGrade.Text = "<font color='" + getColor(getMeltShopStatus(s1, t2)) + "'>" + getGrade(s1, t2) + "</font>";
        this.LBLSLMFHeat.Text = "<font color='" + getColor(getMeltShopStatus(s1, t2)) + "'>" + getHeat(s1, t2) + "</font>";
        if (getMeltShopStatus(s1, t2) == "ON")
        {
            this.LBLSLMFImg.Text = "<img alt='' src='../Images/MLmfOn.gif'/>";
        }
        else
        {
            this.LBLSLMFImg.Text = "<img alt='' src='../Images/MLmfOff.gif'/>";
        }

        this.LBLNLMFStatus.Text = "<font color='" + getColor(getMeltShopStatus(s2, t2)) + "'>" + getMeltShopStatus(s2, t2) + "</font>";
        this.LBLNLMFGrade.Text = "<font color='" + getColor(getMeltShopStatus(s2, t2)) + "'>" + getGrade(s2, t2) + "</font>";
        this.LBLNLMFHeat.Text = "<font color='" + getColor(getMeltShopStatus(s2, t2)) + "'>" + getHeat(s2, t2) + "</font>";
        if (getMeltShopStatus(s2, t2) == "ON")
        {
            this.LBLNLMFImg.Text = "<img alt='' src='../Images/MLmfOn.gif'/>";
        }
        else
        {
            this.LBLNLMFImg.Text = "<img alt='' src='../Images/MLmfOff.gif'/>";
        }

        this.LBLSCasterStatus.Text = "<font color='" + getColor(getCasterStatus(s1)) + "'>" + getCasterStatus(s1) + "</font>";
        this.LBLNCasterStatus.Text = "<font color='" + getColor(getCasterStatus(s2)) + "'>" + getCasterStatus(s2) + "</font>";
    }
    protected void btn_Refresh_Click(object sender, EventArgs e)
    {

    }
    public String getColor(String color)
    {
        switch (color)
        {
            case "Casting":
                color = "Black";
                break;
            case "ON":
                color = "Black";
                break;
            case "IDLE":
                color = "orange";
                break;
            case "Caster Ready":
                color = "Black";
                break;
            default:
                color = "red";
                break;
        }
        return color;
    }

    public String getMeltShopStatus(char furnace, char type)
    {
        HMProdDataContext db = new HMProdDataContext();
        var query = (from p in db.melt_shop_status
                     where p.furnace_location == furnace
                     where p.furnace_type == type


                     select p.status_cd).SingleOrDefault();

        String Status = query.ToString();


        switch (Status)
        {
            case "ON":
                Status = "ON";
                break;
            case "OF":
                Status = "OFF";
                break;
            case "ID":
                Status = "IDLE";
                break;
            
        }
        return Status;

    }

    public String getCasterStatus(char caster)
    {
        HMProdDataContext db = new HMProdDataContext();
        var query = (from p in db.caster_status
                    where p.caster_id == caster


                    select p.status_cd).SingleOrDefault();

        String Status = query.ToString();
        
         
         switch (Status)
         {
             case "CA":
                 Status = "Casting";
                 break;
             case "DI":
                 Status = "Dummy bar insert";
                 break;
             case "MM":
                 Status = "Maintenance Mode";
                 break;
             case "RD":
                 Status = "Caster Ready";
                 break;
             case "CO":
                 Status = "Cold Run";
                 break;
             case "OF":
                 Status = "OFF";
                 break;
             case "TO":
                 Status = "Tailout";
                 break;
         }
         return Status;

    }

    public String getGrade(char furnace, char type)
    {
        HMProdDataContext db = new HMProdDataContext();
        var query = (from p in db.melt_shop_status
                     where p.furnace_location == furnace
                     where p.furnace_type == type


                     select p.grade).SingleOrDefault();
        if (query.ToString() == "")
        {
            query = "{Empty}";
        }

        return query.ToString();
    }

    public String getHeat(char furnace, char type)
    {
        HMProdDataContext db = new HMProdDataContext();
        var query = (from p in db.melt_shop_status
                     where p.furnace_location == furnace
                     where p.furnace_type == type


                     select p.heat_no).SingleOrDefault();

        return query.ToString();
    }

    protected void btn_Menu_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("~/MobileMenu.aspx");
    }
}
