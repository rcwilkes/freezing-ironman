﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OracleClient;

public partial class Reports_HMProdReport : System.Web.UI.Page
{
    public enum Shift
    {
        Night = 0,
        Day = 1,
        Both = 2
    }

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        SetLabels();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        PlaceHolder holder = (PlaceHolder)Page.Master.FindControl("MainPlaceHolder");
        holder.Controls.Add(new LiteralControl(" > "));
        holder.Controls.Add(new LiteralControl("<span style='font-weight: bold;'>HM Production</span>"));
        
    }

    public String getcoilCount(DateTime start, DateTime end)
    {
        HMProdDataContext db = new HMProdDataContext();
        var query = (from p in db.hb_coil_product_datas
                     where p.produced_dt_stamp > start
                     where p.produced_dt_stamp < end

                     select p).Count().ToString("N0");

        return query;
    }
    public String gettonSum(DateTime start, DateTime end)
    {
        float tonSum = 0;
        HMProdDataContext db = new HMProdDataContext();
        float? coilweight =
     (from coil in db.hb_coil_product_datas
      where coil.produced_dt_stamp > start
      where coil.produced_dt_stamp < end
      select coil.actual_coil_weight / 2000).Sum();

        float.TryParse(coilweight.ToString(), out tonSum);
        return tonSum.ToString("N");

    }



    void SetLabels()
    {
        DateTime E = DateMenu.Date.Value;// Convert.ToDateTime(TBStartDate.Text);
        DateTime S = E;
        if (DateMenu.Shift.Value == "Day")
        {
            S = Convert.ToDateTime(S.ToShortDateString() + " 7:00 AM");
            E = Convert.ToDateTime(E.ToShortDateString() + " 7:00 PM");
        }
        else if (DateMenu.Shift.Value == "Night")
        {
            S = Convert.ToDateTime(S.ToShortDateString() + " 7:00 PM");
            E = Convert.ToDateTime(E.ToShortDateString() + " 7:00 AM");
            E = DateTime.Parse(E.ToString()).AddDays(1);
        }
        else
        {
            S = Convert.ToDateTime(S.ToShortDateString() + " 7:00 AM");
            E = Convert.ToDateTime(E.ToShortDateString() + " 7:00 AM");
            E = DateTime.Parse(E.ToString()).AddDays(1);
        }


        LBLCoilCount.Text = getcoilCount(S, E);
        LBLTonTotal.Text = gettonSum(S, E);
        LBLSTonsShipped.Text = GetShipTotals(S, E);

        //DateTime MS = getmonthStart(S.Month, S.Year.ToString());
        DateTime MS = NSDFiscalCalendar.GetMonthStart(S);
        //DateTime ME = getmonthEnd(S.Month, S.Year.ToString());
        DateTime ME = NSDFiscalCalendar.GetMonthEnd(S);

        LBLMCoilCount.Text = getcoilCount(MS, ME);
        LBLMTonTotal.Text = gettonSum(MS, ME);
        LBLMTonsShipped.Text = GetShipTotals(MS, ME);

        DateTime WS = getweekStart(S);
        DateTime WE = getweekStart(S).AddDays(7);

        

        LBLWCoilCount.Text = getcoilCount(WS, WE);
        LBLWTonTotal.Text = gettonSum(WS, WE);
        LBLWTonsShipped.Text = GetShipTotals(WS, WE);
        //this.LBLWCoilCount.Text = getweekStart(S).ToString();
        //this.LBLWTonTotal.Text = getweekStart(S).AddDays(7).ToString();
        Double SHBA = Convert.ToDouble(LBLMTonsShipped.Text) - Convert.ToDouble(LBLMTonTotal.Text);

        if (SHBA < 0)
        {
            LBLShippedBA.Text = "<font color='red'>" + SHBA.ToString("N") + "</font>";
        }
        LBLShift.Visible = false;
    }

    public String GetShipTotals(DateTime start, DateTime end)
    {
        int TonCount = 0;
        String ST = start.ToString("yyyy-MM-dd HH:mm:ss");
        String ET = end.ToString("yyyy-MM-dd HH:mm:ss");
        OracleConnection conn = null;
        OracleDataReader reader = null;
        OracleCommand command = null;

        try
        {
            conn = new OracleConnection(ConfigurationManager.ConnectionStrings["shippingConnectionString"].ConnectionString);
            command = conn.CreateCommand();
            command.CommandText = "SELECT sum(ship_wgt)/2000 as Shipped_Tons " +
                                    "FROM v_load_info " +
                                    "WHERE date_time_out >= to_date('" + ST +
                                    "', 'YYYY-MM-DD HH24:MI:SS')   " +
                                    "and date_time_out < to_date('" + ET +
                                    "', 'YYYY-MM-DD HH24:MI:SS')  " +
                                    "and substr(load_num,1,1) in ('H','C','O','Z')";



            conn.Open();

            reader = command.ExecuteReader();

            if (reader.Read())
            {
                TonCount = Convert.ToInt32(reader["Shipped_Tons"]);
            }

        }
        catch
        {

        }
        finally
        {
            reader.Close();
            conn.Close();
        }

        return TonCount.ToString("N");
    }

    public DateTime getweekStart(DateTime start)
    {
        double offset = 0;
        switch (start.DayOfWeek)
        {
            case DayOfWeek.Monday:
                offset = -1;
                break;
            case DayOfWeek.Tuesday:
                offset = -2;
                break;
            case DayOfWeek.Wednesday:
                offset = -3;
                break;
            case DayOfWeek.Thursday:
                offset = -4;
                break;
            case DayOfWeek.Friday:
                offset = -5;
                break;
            case DayOfWeek.Saturday:
                offset = -6;
                break;
            case DayOfWeek.Sunday:
                offset = 0;
                break;
        }
        return start.AddDays(offset);
    }

    //protected void btn_Day_Click(object sender, EventArgs e)
    //{
    //    LBLShift.Text = "Day";
    //    SetLabels(Shift.Day);

    //}
    //protected void btn_Night_Click(object sender, EventArgs e)
    //{
    //    LBLShift.Text = "Night";
    //    SetLabels(Shift.Night);
    //}

    //protected void btn_Both_Click(object sender, EventArgs e)
    //{
    //    SetLabels(Shift.Both);
    //}

    //protected void btn_Menu_Click(object sender, EventArgs e)
    //{
    //    Page.Response.Redirect("~/MobileMenu.aspx");
    //}
    //protected void LinkButton1_Click(object sender, EventArgs e)
    //{
    //    DateTime S = DateMenu.Date.Value;// Convert.ToDateTime(TBStartDate.Text);
    //    if (LBLShift.Text == "Day")
    //    {
    //        S = S.AddDays(-1);
    //        //TBStartDate.Text = S.ToShortDateString();
    //        SetLabels(Shift.Night);
    //        LBLShift.Text = "Night";
    //    }
    //    else if (LBLShift.Text == "")
    //    {
    //        S = S.AddDays(-1);
    //        //TBStartDate.Text = S.ToShortDateString();
    //        SetLabels(Shift.Night);
    //        LBLShift.Text = "Night";
    //    }
    //    else
    //    {
    //        SetLabels(Shift.Day);
    //        LBLShift.Text = "Day";
    //    }
    //}
    //protected void LinkButton2_Click(object sender, EventArgs e)
    //{
    //    DateTime S = DateMenu.Date.Value;// Convert.ToDateTime(TBStartDate.Text);
    //    if (LBLShift.Text == "Night")
    //    {
    //        S = S.AddDays(1);
    //        //TBStartDate.Text = S.ToShortDateString();
    //        SetLabels(Shift.Day);
    //        LBLShift.Text = "Night";
    //    }
    //    else
    //    {
    //        SetLabels(Shift.Night);
    //        LBLShift.Text = "Night";
    //    }
    //}
}
