﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using CML2.Common;
using CML2.Reports;
using System.Collections.Generic;

public partial class Reports_CMProdReport : System.Web.UI.Page
{
    //ImageButton prev = new ImageButton();
    //ImageButton next = new ImageButton();
    Label dateLabel = new Label();
    Label shiftLabel = new Label();


    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        Render();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        PlaceHolder holder = (PlaceHolder)Page.Master.FindControl("MainPlaceHolder");
        holder.Controls.Add(new LiteralControl(" > "));
        holder.Controls.Add(new LiteralControl("<span style='font-weight: bold;'>CM Production</span>"));
    }




    public void Render()
    {
        ContentPlaceHolder.Controls.Clear();

        if (dateLabel.Text == "")
        {
            shiftLabel.Text = DateMenu.Shift.Value + " Shift";
            dateLabel.Text = DateMenu.Date.Value.ToShortDateString();

            if (DateMenu.Shift.Value == "Day")
                dateLabel.Text += " 7:00:00 AM";
            else
                dateLabel.Text += " 7:00:00 PM";
            
        }


        DateTime shiftStart = Convert.ToDateTime(dateLabel.Text);
        DateTime weekStart = GetWeekStart(shiftStart);
        DateTime monthStart = NSDFiscalCalendar.GetMonthStart(shiftStart);
        DateTime monthEnd = NSDFiscalCalendar.GetMonthEnd(shiftStart);


        List<CMTotal> dayTotals = CMTotal_DAL.GetAllByDateRange(shiftStart, shiftStart.AddHours(12));
        List<CMTotal> weekTotals = CMTotal_DAL.GetAllByDateRange(weekStart, weekStart.AddDays(7));
        List<CMTotal> monthTotals = CMTotal_DAL.GetAllByDateRange(monthStart, monthEnd);

       
        for(int i = 0; i < dayTotals.Count; i++)
        {
            
            switch (dayTotals[i].WorkCenter)
            {
                case WorkCenters._WorkCenters.Annealing:
                    ANShiftLabel.Text = dayTotals[i].CoilCount.ToString() +
                        " coils / " + (dayTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    ANWeekLabel.Text = weekTotals[i].CoilCount.ToString() +
                        " coils / " + (weekTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    ANMonthLabel.Text = monthTotals[i].CoilCount.ToString() +
                        " coils / " + (monthTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    ANBonusLabel.Text = dayTotals[i].Bonus.ToString("#.##") + "%";
                    break;
                case WorkCenters._WorkCenters.Pickle:
                    PLShiftLabel.Text = dayTotals[i].CoilCount.ToString() +
                        " coils / " + (dayTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    PLWeekLabel.Text = weekTotals[i].CoilCount.ToString() +
                        " coils / " + (weekTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    PLMonthLabel.Text = monthTotals[i].CoilCount.ToString() +
                        " coils / " + (monthTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    PLBonusLabel.Text = dayTotals[i].Bonus.ToString("#.##") + "%";
                    break;
                case WorkCenters._WorkCenters.Tandem:
                    TAShiftLabel.Text = dayTotals[i].CoilCount.ToString() +
                        " coils / " + (dayTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    TAWeekLabel.Text = weekTotals[i].CoilCount.ToString() +
                        " coils / " + (weekTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    TAMonthLabel.Text = monthTotals[i].CoilCount.ToString() +
                        " coils / " + (monthTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    TABonusLabel.Text = dayTotals[i].Bonus.ToString("#.##") + "%";
                    break;
                case WorkCenters._WorkCenters.Temper:
                    TRShiftLabel.Text = dayTotals[i].CoilCount.ToString() +
                        " coils / " + (dayTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    TRWeekLabel.Text = weekTotals[i].CoilCount.ToString() +
                        " coils / " + (weekTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    TRMonthLabel.Text = monthTotals[i].CoilCount.ToString() +
                        " coils / " + (monthTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    TRBonusLabel.Text = dayTotals[i].Bonus.ToString("#.##") + "%";
                    break;
                case WorkCenters._WorkCenters.GalvLine:
                    GLShiftLabel.Text = dayTotals[i].CoilCount.ToString() +
                        " coils / " + (dayTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    GLWeekLabel.Text = weekTotals[i].CoilCount.ToString() +
                        " coils / " + (weekTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    GLMonthLabel.Text = monthTotals[i].CoilCount.ToString() +
                        " coils / " + (monthTotals[i].Weight / 2000).ToString("N0") +
                        " tons";
                    GLBonusLabel.Text = dayTotals[i].Bonus.ToString("#.##") + "%"; break;
            }
        }

    }

    string GetLabel(string station)
    {
        string label = String.Empty;

        switch (station)
        {
            case "Pickle":
                label = "Pickle Line";
                break;
        }

        return label;
    }

    public string GetImage(String station)
    {
        if (station == "Temper")
        {
            return "<img alt='' src='../Images/CMStatus/MillGraphicsRM1.png'/><div style='color: #116611; font-weight: bold;'>Temper Mill</div>";
        }
        else if (station == "Pickle")
        {
            return "<img alt='' src='../Images/CMStatus/MillGraphicsCMPL.png'/><div style='color: #116611; font-weight: bold;'>Pickle Line</div>";
        }
        else if (station == "Tandem")
        {
            return "<img alt='' src='../Images/CMStatus/MillGraphicsTM.png'/><div style='color: #116611; font-weight: bold;'>Tandem Mill</div>";
        }
        else if (station == "Annealing")
        {
            return "<img alt='' src='../Images/CMStatus/MillGraphicsANL.png'/><div style='color: #116611; font-weight: bold;'>Annealing</div>";
        }


        return "";
    }
    public static string Leftsub(string param, int startIndex)
    {
        string result = param.Substring(startIndex);
        return result;

    }

    public DateTime GetWeekStart(DateTime start)
    {
        double offset = 0;
        switch (start.DayOfWeek)
        {
            case DayOfWeek.Monday:
                offset = -1;
                break;
            case DayOfWeek.Tuesday:
                offset = -2;
                break;
            case DayOfWeek.Wednesday:
                offset = -3;
                break;
            case DayOfWeek.Thursday:
                offset = -4;
                break;
            case DayOfWeek.Friday:
                offset = -5;
                break;
            case DayOfWeek.Saturday:
                offset = -6;
                break;
            case DayOfWeek.Sunday:
                offset = 0;
                break;
        }
        return start.AddDays(offset);
    }

    protected void btn_Menu_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("~/MobileMenu.aspx");
    }

   
}
