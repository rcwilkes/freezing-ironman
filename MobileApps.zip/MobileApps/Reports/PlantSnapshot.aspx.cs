﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Nucor.MIPS;


public partial class Reports_PlantSnapshot : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Title = "Plant Snapshot";

        PlaceHolder holder = (PlaceHolder)Page.Master.FindControl("MainPlaceHolder");
        holder.Controls.Add(new LiteralControl(" > "));
        holder.Controls.Add(new LiteralControl("<span style='font-weight: bold;'>Plant Status</span>"));

        DateTime date = NSDFiscalCalendar.AdjustDateIfShiftSpansMidnight(DateTime.Now);
        DateTime dayStart = Convert.ToDateTime(date.ToShortDateString() + " 7:00 AM");
        DateTime dayEnd = Convert.ToDateTime(dayStart.AddDays(1).ToShortDateString() + " 7:00 AM");
        DateTime weekStart = NSDFiscalCalendar.GetWeekStart(dayStart);
        DateTime weekEnd = weekStart.AddDays(7);
        DateTime monthStart = NSDFiscalCalendar.GetMonthStart(date);
        DateTime monthEnd = NSDFiscalCalendar.GetMonthEnd(date);

        Book_DayLbl.Text = MIPSData.GetBookedTons(dayStart).ToString("N0");
        Book_WeekLbl.Text = MIPSData.GetBookedTons(weekStart).ToString("N0");
        Book_MonthLbl.Text = MIPSData.GetBookedTons(monthStart).ToString("N0");

        HM_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.HM).ToString("N0");
        HM_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.HM).ToString("N0");
        HM_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.HM).ToString("N0");

        PL1_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.PL1).ToString("N0");
        PL1_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.PL1).ToString("N0");
        PL1_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.PL1).ToString("N0");

        PL2_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.PL2).ToString("N0");
        PL2_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.PL2).ToString("N0");
        PL2_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.PL2).ToString("N0");

        TA_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.Tandem).ToString("N0");
        TA_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.Tandem).ToString("N0");
        TA_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.Tandem).ToString("N0");

        AN_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.Annealing).ToString("N0");
        AN_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.Annealing).ToString("N0");
        AN_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.Annealing).ToString("N0");

        TR_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.Temper).ToString("N0");
        TR_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.Temper).ToString("N0");
        TR_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.Temper).ToString("N0");

        GL_DayLbl.Text = MIPSData.GetProducedTons(dayStart, dayEnd, WorkCenter.Galv).ToString("N0");
        GL_WeekLbl.Text = MIPSData.GetProducedTons(weekStart, weekEnd, WorkCenter.Galv).ToString("N0");
        GL_MonthLbl.Text = MIPSData.GetProducedTons(monthStart, monthEnd, WorkCenter.Galv).ToString("N0");


        SH_DayLbl.Text = MIPSData.GetShippedTons(dayStart, dayEnd).ToString("N0");
        SH_WeekLbl.Text = MIPSData.GetShippedTons(weekStart, weekEnd).ToString("N0");
        SH_MonthLbl.Text = MIPSData.GetShippedTons(monthStart, monthEnd).ToString("N0");


        //Response.Write("Day<br>" + MIPSData.GetSQL(dayStart));
        //Response.Write("<br><br>Week<br>" + MIPSData.GetSQL(weekStart));
        //Response.Write("<br><br>Month<br>" + MIPSData.GetSQL(monthStart));

        //Response.Write("DS: " + dayStart.ToString());
        //Response.Write("<br>");
        //Response.Write("DE: " + dayEnd.ToString());
        //Response.Write("<br>");
        //Response.Write("WS: " + weekStart.ToString());
        //Response.Write("<br>");
        //Response.Write("WE: " + weekEnd.ToString());
        //Response.Write("<br>");
        //Response.Write("MS: " + monthStart.ToString());
        //Response.Write("<br>");
        //Response.Write("ME: " + monthEnd.ToString());

        //Response.Write("<br>");
        //Response.Write("WT: " + shippedTonsDay.ToString());
        //Response.Write("<br>");
        //Response.Write("MT: " + shippedTonsWeek.ToString());
        //Response.Write("<br>");
        //Response.Write("MT: " + shippedTonsMonth.ToString());

    }
}
