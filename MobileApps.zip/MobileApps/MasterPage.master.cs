﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class MasterPage : System.Web.UI.MasterPage
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.Request.Path.Substring(Page.Request.Path.LastIndexOf('/') + 1) == "Default.aspx")
        {
            MainMenuLink.Enabled = false;
            TopSpacerPlaceHolder.Controls.Add(new LiteralControl("<br></br>"));
        }

        RefreshLink.NavigateUrl = Page.Request.Path;

        if (!NucorConfig.NucorCommon.Prod)
            RefreshLink.ForeColor = System.Drawing.Color.Red;
            
    }
}
